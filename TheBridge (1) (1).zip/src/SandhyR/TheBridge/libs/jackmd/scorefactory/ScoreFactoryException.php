<?php
declare(strict_types = 1);

namespace SandhyR\TheBridge\libs\jackmd\scorefactory;

class ScoreFactoryException extends \Exception {}